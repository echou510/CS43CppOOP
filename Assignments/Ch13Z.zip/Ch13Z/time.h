#ifndef TIME_H
#define TIME_H
#include <iostream> 
using namespace std; 

static int nums;  // number of time object created. 
class Time{
    int hour; 
    int min; 
    int sec; 
   public: 
    Time(): hour(0), min(0), sec(0){
        cout << "no-arg constructor" << endl; 
        nums++; 
    }  // no-arg consturctor
    Time(int h, int m, int s){  // constructor with argument
        cout << "w-arg constructor" << endl; 
        hour = h; min = m; sec = s; 
        nums++; 
    }
    Time(Time &t){ // copy constructor  a= b
       cout << "copy consturctor" << endl; 
       hour = t.hour; 
       min = t.min; 
       sec = t.sec; 
       nums++; 
    }
   
    int getHour(); // unimplmented functions
    int getMin();
    int getSec();
    void setHour(int h); 
    void setMin(int m); 
    void setSec(int s); 
    void operator=(Time &other);
    bool operator==(Time &other); 
    const string &tostring(); 
    friend string to_string(Time &p){ return p.tostring(); }

    void print(ostream& out){
      out << tostring().c_str();
    }
    friend ostream& operator << (ostream& out, Time& n){
		n.print(out); 
	    return out; 
	}
};   // different from Java.  It needs ;, same as struct
#endif 