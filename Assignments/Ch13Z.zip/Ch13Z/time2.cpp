#include <iostream> 
#include "time.h"
using namespace std; 

extern int nums;
void print(Time &x){ // the use of alias is very important
    cout << x.tostring() << endl;
}

int main(void){
    Time t1(14, 16, 30); // w-arg constructor
    Time t2(4, 4, 4); 
    Time t3(2, 2, 2);
    print(t1); 

    t1.setHour(20); 
    t1.setMin(44); 
    t1.setSec(21); 
    print(t1); 

    t1 = t2; 
    print(t1);

    bool b = t1 == t2; 
    string s = b ? "true" : "false"; 
    cout << "t1==t2 is " << s << endl; 
    bool b2 = t1 == t3; 
    string s1 = b2 ? "true" : "false"; 
    cout << "t1==t3 is " << s1 << endl; 

    cout << "t1: " << t1 << endl; 
    cout << "t2: " << t2 << endl; 
    cout << "t3: " << t3 << endl; 
    cout << nums << endl; 
    return 0; 
}