#include <iostream> 
#include <string>
#include "time.h"
using namespace std; 
int Time::getHour(){ return hour; }
int Time::getMin(){ return min; }
int Time::getSec(){ return sec; }
void Time::setHour(int h){ hour = h; } 
void Time::setMin(int m){ min = m; }
void Time::setSec(int s){ sec = s; }

// Overriding = operator
void Time::operator=(Time &other){
    cout << "overriden = " << endl; 
    hour = other.getHour();
    min = other.getMin(); 
    sec = other.getSec(); 
}

bool Time::operator==(Time &other){
    return hour == other.getHour() 
    && min == other.getMin() && sec == other.getSec();
}

const string &Time::tostring(){
   string s = string("");
   s += "["+to_string(hour)+":"+to_string(min)+":"+to_string(sec)+"]";
   const string *str = new string(s); 
   return *str; 
}

//#define MAIN
#ifdef MAIN
void print(Time &x){
    cout << x.getHour() << ":" << x.getMin() 
         << ":" << x.getSec() << endl;
}

int main(void){
    Time t; 
    cout << t.getHour() << ":" << t.getMin() 
         << ":" << t.getSec() << endl; 
    Time t1(4, 16, 20); 
    cout << t1.getHour() << ":" << t1.getMin() 
         << ":" << t1.getSec() << endl;
    Time t2 = t1; // default copy - constructor
    cout << t2.getHour() << ":" << t2.getMin() 
         << ":" << t2.getSec() << endl;
    Time t3(t1); 
    cout << t3.getHour() << ":" << t3.getMin() 
         << ":" << t3.getSec() << endl;

    print(t3); // no copy constructor

    Time t4{t1}; // will cause copy constructor
    print(t4); // no copy structor
    return 0; 
}
#endif 