#define MAIN
#ifndef LISTNODE_H
#define LISTNODE_H
#include "to_string.h"
using namespace std; 
class listerror{
	public: 
	const char *description; 
	listerror(const char *s){description = s; }
}; 
template <typename T> 
class listnode{
	public: 
	    listnode<T> *next; 
		listnode<T> *prev; 
		listnode<T> *head; 
	    listnode(){next =prev=head=this; }
		listnode(T t){ next =prev=head=this; object = t; }
		listnode<T> *pre(){
			if (prev==this ||  prev==head) return NULL; 
			return prev; 
		}
		listnode<T> *post(){
			if (next==this || next==head) return NULL; 
			return next; 
		}
		bool singleton(){
			return (prev==this); 
		}
		void insert_before(listnode<T> *n){
			if (!n->singleton()) throw new listerror("attempt to insert a node already on the list.");
			prev->next = n; 
			n->prev=prev; 
			n->next=this; 
			prev=n; 
			n->head=head; 
		}
		void remove(){
			if (singleton()) throw new listerror("Attempt to remove node not on the list."); 
		    prev->next = next;  // by pass this
			next->prev = prev; 
			prev = next = head = this;  // to be deleted. 
		}
		~listnode<T>(){ // delete only the singleton nodes
			if (!singleton()) throw new listerror("Attempt to delete node still on the list"); 
		}
		// from dnode definition
		void setNext(listnode<T> *n){ next = n; } 
		void setPrev(listnode<T> *p){ prev = p; }
		listnode<T> *getNext(){ return next; }
		listnode<T> *getPrev(){ return prev; }
		bool hasNext(){
			if (getNext()!= NULL) return true; 
			else return false; 
		}
		bool hasPrev(){
			if (getPrev()!=NULL) return true; 
			else return false; 
		}
		string to_string(){ return st::to_string(object); }
		T get(){ return object; }
	private: 
	    T object; 
}; 
#endif