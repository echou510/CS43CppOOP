#include <iostream>
#include "listnode.h"

#ifdef MAIN
using namespace std; 
int main(){
    listnode<int> *head = new listnode<int>();
    listnode<int> *a = new listnode<int>(3); 
    head->insert_before(a); 
    listnode<int> *b = new listnode<int>(5); 
    a->insert_before(b); 	
	cout << head->getNext()->to_string() << endl; 
	return 0; 
}
#endif