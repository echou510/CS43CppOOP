#define MAIN
#ifndef DYNARRAY_H
#define DYNARRAY_H
#include <cstdlib>
#include <cstdio>
class DynArray{
public:
    DynArray(int arrSize);  			
    DynArray(const DynArray& otherArr);
	~DynArray();		 
	int  ValueAt (int i)  const;		 
	void  Store (int val,  int i); 
    void  CopyFrom (DynArray otherArr);
	int getSize(){ return size; } 
	int *get() { return arr; }
private:
	  int*  arr;
	  int   size;
};
#endif 

