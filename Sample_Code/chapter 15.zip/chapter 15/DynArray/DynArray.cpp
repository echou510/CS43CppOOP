#include <iostream>
#include "DynArray.h"
using namespace std; 

DynArray::DynArray(int arrSize){  			
    int i; 	
    if (arrSize < 1) {
        cerr << "DynArray constructor - invalid size: "
		       << arrSize << endl;
        exit(1);
	   }
	  arr = new  int[arrSize];	  // Allocate memory 
	  size = arrSize;
	  for (i = 0; i < size;  i++)arr[i] = 0;
}
DynArray::DynArray(const DynArray& otherArr){
    int i;
    size = otherArr.size;
    arr = new  int[size];	  // Allocate memory for copy
    for (i = 0; i< size; i++)
        arr[i] = otherArr.arr[i];     // Copies array
}	

void  DynArray::Store (int val,  int i){	 
	  if (i < 0 || i >= size) {
		  cerr << "Store - invalid index : " << i << endl;
		  exit(1);
    }
	arr[i] = val;
}	

int  DynArray::ValueAt (int i)  const {		 
    if (i < 0 || i >= size) {
        cerr << "ValueAt - invalid index : " << i 
           << endl;
        exit(1);
    }
    return arr[i];
}
void  DynArray::CopyFrom (DynArray  otherArr){	
    int i;

    delete[ ]  arr;		// Delete current array
    size = otherArr.size;
    arr = new int [size];		// Allocate new array

    for (i = 0; i< size; i++)  // Deep copy array
        arr[i] = otherArr.arr[i];        
}	
DynArray::~DynArray(){
    delete [ ] arr;
}
void  SomeFunc(DynArray  someArr){
	int *arr = someArr.get(); 
	for (int i=0; i< someArr.getSize();  i++){
	      if (i!=0) cout << " " << arr[i]; else cout << arr[i];  
	}
	cout << endl; 
}

#ifdef MAIN
int main(int argc, char **argv){
	DynArray *a = new DynArray(3); 

	cout << "Number of element in a[]=" << a->getSize() << endl; 
	a->Store(3, 0); a->Store(6, 1); a->Store(9, 2); 
	SomeFunc(*a); 
	
	DynArray b(*a);   // copy constructor

	b.Store(2, 0); b.Store(4, 1); b.Store(6, 2); 
	cout << "Number of element in b[]=" << b.getSize() << endl;
	SomeFunc(b); 
	
	a->CopyFrom(b); 
	cout << "Number of element in a[]=" << a->getSize() << endl; 
	SomeFunc(*a); 
	
	a->~DynArray(); 
	printf("Pointer a = %d after ~DynArray() \n", a); 
}
#endif 


