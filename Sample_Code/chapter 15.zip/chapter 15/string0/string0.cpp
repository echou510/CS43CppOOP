#include<iostream> 
#include <cstdio>
#include <string> 
using namespace std; 

char a[] = "How are you?";  
string c("How are you!"); 

int main(){
  char *b = a; 
  int i=0; 
  printf("%s\n", a); 
  while (*b != '\0'){ // '\0' is the end of the character array assigned wiht "string"
	   cout << *b; 
	   b ++; 
	   i  ++; 
  }  
  cout << endl; 
  for (i=0; i< sizeof(a)/sizeof(char); i++){ // '\0' is the end of the char array.  So, there is one empty character. 
	  cout << "a[" << i <<"]=" << a[i] << " "; 
  }
  cout << endl; 
  cout << "Difference between char array[] and string" <<endl; 
  cout << "sizeof(a)==" << sizeof(a)/sizeof(char) << " != " <<  "c.length()==" << c.length() << endl; 
  cout << "String Traversal 1: " <<endl; 
  for (i=0; i<c.length() ; i++){
	   cout << "c[" << i <<"]=" << c[i] << " "; 
  }
  cout << endl; 
  cout << "String Traversal 2: " <<endl; 
  for (string::iterator it=c.begin(); it!=c.end(); ++it) cout << *it << "_";
  cout << '\n';
  cout << "String Traversal 3: " <<endl; 
 for (i=0; i<c.length(); i++) printf("%c ", c.at(i)); 
}