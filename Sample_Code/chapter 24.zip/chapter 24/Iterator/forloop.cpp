#include <iostream>
#include <vector>
using namespace std;

int main()
{
  //decleration of int vector
  vector<int> vec = {1, 2, 3, 4, 5};
  
  // returns length of vector as unsigned int
  unsigned int vecSize = vec.size();

  // run for loop from 0 to vecSize
  for(unsigned int i = 0; i < vecSize; i++)
  {
    cout << vec[i] << " ";
  }
  cout << endl;

  return 0;
}