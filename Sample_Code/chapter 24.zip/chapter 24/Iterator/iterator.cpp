#include <iostream>
#include <vector>
using namespace std;

int main(){
  vector<int> vec = {1, 2, 3, 4, 5};
  int vecSize = vec.size(); // returns length of vector

  vector<int>::iterator iter = vec.begin();

  cout << "Vector: ";
 
  for(iter; iter < vec.end(); iter++)
  {
    // access value in the memory to which the pointer
    // is referencing
    cout << *iter << " ";
  }
  cout << endl;
  return 0;
}