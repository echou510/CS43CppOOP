#include <iostream> 

using namespace std; 
int a[] = {3, 7, 1, 9, 5, 4, 8, 10, 2, 6}; 
int asize = 10; 

void sort(int a[], int len){
   for (int i=0; i<len-1; i++){
     int min = a[i]; 
     int idx = i; 
     for (int j=i+1; j<len; j++){
         if (a[j]<min) {min = a[j]; idx = j; }
     }

     if (i!=idx){
         int tmp = a[i]; 
         a[i] = a[idx]; 
         a[idx] = tmp; 
     }
   }
}

void printArray(int a[], int len){
    cout << "[" ; 
    for (int i=0; i<len; i++){
      if (i==0) cout << a[i]; 
      else cout << ", " << a[i]; 
    }
    cout << "]" << endl; 
}

int main(void){
    printArray(a, asize); 
    sort(a, asize); 
    printArray(a, asize); 
    return 0; 
}
