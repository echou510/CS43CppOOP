#include <iostream> 

using namespace std; 
int a[] = {3, 7, 1, 9, 5, 4, 8, 10, 2, 6}; 
int asize = 10; 

int *merge(int *a, int *b, int na, int nb); 
int *sort(int *a, int len){
   if (len<=1) return a; 
   int low = 0; 
   int high = len-1; 
   int mid = (low+high)/2; 
   int esize = mid+1; 
   int *e = new int[esize];
   int fsize = len-mid-1;  
   int *f = new int[fsize];
   int p =0; 
   for (int i=0; i<esize; i++){
       e[i] = a[p++];
   } 
   for (int i=0; i<fsize; i++){
       f[i] = a[p++]; 
   }
   e = sort(e, esize); 
   f = sort(f, fsize); 
   a = merge(e, f, esize, fsize); 
   delete[] e; 
   delete[] f; 
   return a; 
}

int *merge(int *a, int *b, int na, int nb){
    int *c = new int[na+nb]; 
    int p=0, q=0, r=0; 
    while (p<na && q<nb){
       if (a[p]<b[q]) c[r++] = a[p++]; 
       else c[r++] = b[q++];
    }
    while (p<na) c[r++] = a[p++]; 
    while (q<nb) c[r++] = b[q++]; 
    return c; 
}

void printArray(int a[], int len){
    cout << "[" ; 
    for (int i=0; i<len; i++){
      if (i==0) cout << a[i]; 
      else cout << ", " << a[i]; 
    }
    cout << "]" << endl; 
}

int main(void){
    int *b = a; 
    printArray(b, asize); 
    b=sort(b, asize); 
    printArray(b, asize); 
    return 0; 
}
