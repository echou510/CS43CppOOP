#include <iostream> 
#include "tnode.h"
using namespace std; 
int main(){
    tnode<int> *t1 = new tnode<int>(3); 
    tnode<int> *t2 = new tnode<int>(2); 
    tnode<int> *t3 = new tnode<int>(4); 

    t1->setLeft(t2);
    t1->setRight(t3);  
    inorder(t1); 
    cout << endl; 
    preorder(t1); 
    cout << endl; 
    postorder(t1); 
    delete t1, t2, t3; 
    return 0; 
}