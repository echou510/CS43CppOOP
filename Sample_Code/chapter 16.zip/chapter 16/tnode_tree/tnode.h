#ifndef TNODE_H
#define TNODE_H
#include <cstring> 
#include <string> 
#include <iostream> 
using namespace std; 

template<typename T> 
class tnode{
      T val; 
      tnode<T> *left; 
      tnode<T> *right; 
      char buf[256]; 
    public: 
      tnode(): val(0), left(nullptr), right(nullptr){}
      tnode(int v): val(v), left(nullptr), right(nullptr){}
      tnode(int v, tnode<T> *lp, tnode<T> *rp): val(v), left(lp), right(rp){}
      tnode(tnode<T> &p): val(p.val), left(p.left), right(p.right){} 
      void operator=(tnode<T> &p){ val = p.val; left = p.left; right=p.right;}

      T get(){ return val; }
      void set(int v){ val = v; }
      tnode<T> *getLeft(){ return left; }
      void setLeft(tnode<T> *ll){ left=ll; }
      bool hasLeft(){ return left != nullptr; }
      tnode<T> *getRight(){ return right; }
      void setRight(tnode<T> *rr){ right=rr; }
      bool hasRight(){ return right != nullptr; }

      string tostring(){ return to_string(val); }
      friend string to_string(tnode<T> &p){ return p.tostring(); }

    void print(ostream& out){
      out << tostring().c_str();
    }
    
    void read(istream& in){
      in >> buf;
      val = atoi(buf); // ASCII to integer in cstring
    }
    
    friend ostream& operator<<(ostream& out, tnode<T>& n){
		     n.print(out); 
		     return out; 
	}
    
    friend istream& operator>>(istream& in, tnode<T>& n){
		    n.read(in); 
		    return in; 
	}

    friend void inorder(tnode<T> *top){
        if (top==nullptr) return; 
        cout << "[" ; 
        inorder(top->getLeft()); 
        if (top->getLeft()) cout << ", " ; 
        cout << top->val;   
        if (top->getRight()) cout << ", " ; 
        inorder(top->getRight()); 
        cout << "]"; 
    }

    friend void preorder(tnode<T> *top){
        if (top==nullptr) return; 
        cout << "{" ; 
        cout << top->val; 
        if (top->getLeft()) cout << "->"; 
        preorder(top->getLeft()); 
        if (top->getRight()) cout << "->" ; 
        preorder(top->getRight()); 
        cout << "}"; 
    }

    friend void postorder(tnode<T> *top){
        if (top==nullptr) return; 
        cout << "(" ; 
        postorder(top->getLeft()); 
        if (top->getLeft()) cout << "->" ; 
        postorder(top->getRight()); 
        if (top->getRight()) cout << "->"; 
        cout << top->val; 
        cout << ")"; 
    }
}; 
#endif 