#ifndef TREE_H
#define TREE_H
#include <cstring> 
#include <string> 
#include <iostream> 
#include "tnode.h"
using namespace std; 

template <typename T>
class tree{
      tnode<T> *root; 
    public: 
      tree(): root(nullptr){}

      void add(int v){
          if (!root){
              tnode<T> *n = new tnode<T>(v); 
              root = n; 
              return; 
          }
          addx(root, v); 
      }

      void addx(tnode<T> *top, int v){
          if (v < top->get()){
              if (top->hasLeft()){
                 addx(top->getLeft(), v); 
              }
              else {
                 tnode<T> *n = new tnode<T>(v); 
                 top->setLeft(n); 
                 return; 
              }
          }
          if (v > top->get()){
              if (top->hasRight()){
                 addx(top->getRight(), v); 
              }
              else {
                 tnode<T> *n = new tnode<T>(v); 
                 top->setRight(n); 
                 return; 
              }
          }
      }

      void print(){
         inorder(root); 
      }
}; 
#endif 