#define MAIN
#ifndef NODE_H
#define NODE_H
#include "to_string.h"
using namespace std; 
template <typename T> 
class node{
	public: 
	    node<T> *next; 
	    node(): object(NULL), next(NULL){}
		node(T t){ next = NULL;  object = t; }
		void setNext(node<T> *n){ next = n; } 
		node<T> *getNext(){ return next; }
		bool hasNext(){
			if (getNext()!= NULL) return true; 
			else return false; 
		}
		string to_string(){ return st::to_string(object); }
		T get(){ return object; }
	private: 
	    T object; 
}; 
#endif

