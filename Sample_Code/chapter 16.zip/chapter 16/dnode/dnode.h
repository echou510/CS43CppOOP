#define MAIN
#ifndef DNODE_H
#define DNODE_H
#include "to_string.h"
using namespace std; 
template <typename T> 
class dnode{
	public: 
	    dnode<T> *next; 
		dnode<T> *prev; 
	    dnode(): next(NULL), prev(NULL) {}
		dnode(T t){ next=NULL; prev=NULL; object = t; }
		void setNext(dnode<T> *n){ next = n; } 
		void setPrev(dnode<T> *p){ prev = p; }
		dnode<T> *getNext(){ return next; }
		dnode<T> *getPrev(){ return prev; }
		bool hasNext(){
			if (getNext()!= NULL) return true; 
			else return false; 
		}
		bool hasPrev(){
			if (getPrev()!=NULL) return true; 
			else return false; 
		}
		string to_string(){ return st::to_string(object); }
		T get(){ return object; }
	private: 
	    T object; 
}; 
#endif

