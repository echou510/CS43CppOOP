#include <iostream>
#include "dnode.h"
using namespace std; 

#ifdef MAIN
int main(){
	dnode<int> *a = new dnode<int>(3); 
	dnode<int> *b = new dnode<int>(5); 
	dnode<int> *c = new dnode<int>(6); 
	a->setNext(b); 
	b->setNext(c); 
	c->setPrev(b); 
	b->setPrev(a); 

	dnode<int> *p = a; 
	while (p!=NULL) {
		cout << p->to_string() << endl; 
		p = p->next; 
	}
	
    dnode<double> *d = new dnode<double>(2.0); 
	dnode<double> *e = new dnode<double>(4.0); 
	dnode<double> *f = new dnode<double>(8.0); 
	d->setNext(e); 
	e->setNext(f); 
	f->setPrev(e); 
	e->setPrev(d); 
	
	dnode<double> *q = d; 
	while (q!=NULL) {
		cout << q->to_string() << endl; 
		q = q->next; 
	}
	
	dnode<int> *r = c; 
	while (r!=NULL){
		cout << r->to_string() << endl; 
		r = r->prev; 
	}
	
	dnode<double> *s = f; 
	while (s!=NULL){
		cout << s->to_string() << endl; 
		s = s->prev; 
	}
	return 0; 
}
#endif