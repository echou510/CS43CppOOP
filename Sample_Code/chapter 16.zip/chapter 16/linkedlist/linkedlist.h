#define MAIN
#ifndef LINKEDLIST_H
#define LINKEDLIST_H
#include "node.h"
#include "to_string.h"
using namespace std; 
template <typename T> 
class linkedlist{
  public: 
     // data 
	 int length; 
	 node<T> *head, *tail; 
	 
	 // constructor
	 linkedlist(){ head=NULL; tail=NULL; length=0; }
	 
	 // methods
	 int size(); 
	 bool isempty(); 
	 int indexOf(T obj); 
	 T get(int idx); 
	 string to_string();
	 void set(int idx, T v); 
	 void add(T v); 
	 void add_front(T v); 
	 void insert(int idx, T v); 
	 node<T> *remove(); 
	 node<T> *remove_front(); 
	 void append(linkedlist<T> *alist); 
}; 
#endif

