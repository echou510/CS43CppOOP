#include <iostream>
#include "node.h"
using namespace std; 

#ifdef MAIN
int main(){
	node<int> *a = new node<int>(3); 
	node<int> *b = new node<int>(5); 
	node<int> *c = new node<int>(6); 
	a->setNext(b); 
	b->setNext(c); 
	node<int> *p = a; 
	while (p!=NULL) {
		cout << p->to_string() << endl; 
		p = p->next; 
	}
	
    node<double> *d = new node<double>(2.0); 
	node<double> *e = new node<double>(4.0); 
	node<double> *f = new node<double>(8.0); 
	d->setNext(e); 
	e->setNext(f); 
	node<double> *q = d; 
	while (q!=NULL) {
		cout << q->to_string() << endl; 
		q = q->next; 
	}
	return 0; 
}
#endif