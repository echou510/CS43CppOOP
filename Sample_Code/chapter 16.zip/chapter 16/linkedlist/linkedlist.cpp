#include <iostream> 
#include <string>
#include <exception>
#include "linkedlist.h"
#include "to_string.h"
using namespace std; 

template<typename T>
int linkedlist<T>::size(){  // list.length can also be used. 
	return length; 
}

template<typename T>
bool linkedlist<T>::isempty(){
	return (length==0); 
}

template <typename T>
int linkedlist<T>::indexOf(T obj){
	node<T> *p = head; 
	
	int i = 0; 
	int idx = -1; 
	bool found = false; 
	
	while (p != NULL && !found){
		 if (p->get() == obj){
			 idx = i; 
		 }
		i++;
		p = p->next; 
	}
	return idx; 
}

template <typename T>
T linkedlist<T>::get(int idx){
	T rtn; 
	node<T>*p = head; 
	if (head == NULL){
		throw "empty list";
	}
	if (idx<0 || idx>=length){
		throw "index out of bound";
	}
   for (int i=0; i<=idx; i++){
	   if (i==idx) rtn = p->get(); 
	   p = p->next; 
   }
   return rtn; 
}

template <typename T>
void linkedlist<T>::set(int idx, T v){
	node<T>*p = head; 
	if (head == NULL){
		throw "empty list";
	}
	if (idx<0 || idx>=length){
		throw "index out of bound";
	}
   for (int i=0; i<=idx; i++){
	   if (i==idx) p->set(v); 
	   p = p->next; 
   }
}

template <typename T>
void linkedlist<T>::add(T v){
	length++; 
	node<T> *n = new node<T>(v); 
	if (head == NULL){
    	head = n; 
	    head->next = NULL;
		tail = n; 
		return; 
    }	
	
    node<T> *p = (node<T> *) head; 
	node<T> *q = NULL; 
	    while (p!= NULL){
		 q = p; 
		 p=p->next; 
	}  
	tail = n; 
	q->next = n; 
	n->next = NULL; 
}

template <typename T>
void linkedlist<T>::add_front(T v){
	length++; 
	node<T> *n = new node<T>(v); 
	if (head == NULL){
    	head = n; 
	    head->next = NULL;
		tail = n; 
		return; 
    }	
	
    node<T> *p = (node<T> *) head; 
	head = n; 
	n->next = p; 
}

template <typename T>
void linkedlist<T>::insert(int idx, T v){
	//cout << idx << "-"<< v << endl; 
	if (head == NULL){
		//length++; 
		add(v); 
		return; 
	}
	if (idx<0 || idx>length){
		throw "index out of bound";
	}	
	
	if (idx==0)          { add_front(v); return; }
    if (idx==length) { add(v);             return; }
	
	length++; 
	node<T>*p = head;
    node<T>*q = NULL; 
	for (int i=0; i<=idx; i++){
	   if (i==idx) {
		   //cout << i << " " << q->get() << " " << p->get() << endl; 
		  node<T> *n = new node<T>(v); 
          q->next =n; 		  
		  n->next =p;
	   } 
	   q = p; 
	   p = p->next; 
   }
}

template <typename T>
node<T>* linkedlist<T>::remove(){
	if (head == NULL){ // zero element
		return NULL; 
    }	
	
	length--; 
    node<T> *p = (node<T> *) head; 
	node<T> *q = NULL; 
	node<T> *r = NULL;
	    while (p!= NULL){
		r = q; 
		 q = p; 
		 p=p->next; 
	}  
	
	if (r==NULL){ // only one element
		head = NULL; 
		tail = NULL; 
		return q; 
	}
	
	r->next = NULL; 
	tail = r; 
	return q; 
}

template <typename T>
node<T>* linkedlist<T>::remove_front(){
	if (head == NULL){ // zero element
		return NULL; 
    }	
	
	length--; 
	if (head->next == NULL){
		node<T>* q = head; 
		head = NULL; 
		tail = NULL; 
		return q; 
	}
	
	node<T>* q = head; 
	head = head->next; 
	return q; 
}

template <typename T>
string linkedlist<T>::to_string(){
   string str("");
   node<T> *p = head; 
    str += "[";
    int count = 0; 	
    while (p!= NULL){
		 if (count ==0) str += st::to_string(head->get());
         else str += ", "+ st::to_string(p->get());
		 count++;
		 p=p->next; 
	}  
    str += "]"; 	
	return str; 
}

template <typename T>
void linkedlist<T>::append(linkedlist<T> *alist){
	 if (head == NULL) {
		 head = alist->head;
         tail    = alist->tail;
         return;  		 
	 }
	 
	 tail->next = alist->head; 
	 tail = alist->tail; 
}

#ifdef MAIN
int main(){
	// creation of linked list
    linkedlist<int>  *ptr = new linkedlist<int>(); 
    ptr->add(3); 
    ptr->add(4); 
    ptr->add(5); 
    ptr->add(6); 
	
	// testing indexOf
	cout << "\nindexOf():"<< endl; 
	cout << ptr->indexOf(5) << endl; 
	cout << ptr->indexOf(-3) << endl; 
	cout << ptr->indexOf(6) << endl; 
	cout << ptr->indexOf(8) << endl; 
    cout << ptr->to_string() << endl; 
	
	// testing linkedlist get() method
	cout << "\nget():"<< endl; 
	try {
	    cout << ptr->get(2) << endl; 
		cout << ptr->get(8) << endl; 
	}
	catch (const char *e){
		cout << "Exception: " << e << endl;
	}
	
	// testing linkedlist set(idx, v) method
	cout << "\nset():"<< endl; 
	try {
         ptr->set(2, 15); 
		   cout << ptr->to_string() << endl; 
	}
	catch (const char *e){
		cout << "Exception: " << e << endl;
	}
	
	// testing length
    cout << "\nlength:"<< endl; 
	cout << "size()="<< ptr->size() << " length=" << ptr->length << endl; 
	
	// test add_front 
	cout << "\nadd_front():"<< endl; 
    linkedlist<int>  *ptr1 = new linkedlist<int>(); 
    ptr1->add_front(3); 
	ptr1->add_front(4); 
	ptr1->add_front(5); 
	ptr1->add_front(6); 
	cout << ptr1->to_string() << endl; 	
	cout << "size()="<< ptr1->size() << " length=" << ptr1->length << endl; 
	
	// testing remove
	cout << "\nremove():"<< endl; 
	ptr->remove(); 	ptr->remove(); 
	cout << ptr->to_string() << endl; 
	cout << "size()="<< ptr->size() << " length=" << ptr->length << endl; 
	ptr->remove(); 	ptr->remove(); ptr->remove(); 	ptr->remove(); 
	cout << ptr->to_string() << endl; 
	cout << "size()="<< ptr->size() << " length=" << ptr->length << endl; 
	
	// test remove_front
	cout << "\nremove_front():"<< endl; 
	ptr1->remove_front(); 	ptr1->remove_front(); 
	cout << ptr1->to_string() << endl; 
	cout << "size()="<< ptr1->size() << " length=" << ptr1->length << endl; 
	ptr1->remove_front(); 	ptr1->remove_front(); ptr1->remove_front(); 	ptr1->remove_front(); 
	cout << ptr1->to_string() << endl; 
	cout << "size()="<< ptr1->size() << " length=" << ptr1->length << endl; 
	
	// testing isempty()
   cout << "\nisempty():"<< endl; 
	cout << ptr1->isempty() << endl; 
	
	// test try-catch block 
	cout << "\ntry-catch:"<< endl; 
	try {
	    cout << ptr1->get(0) << endl; 
	}
	catch (const char *e){
		cout << "Exception: " << e << endl;
	}
	
	// test insert(idx, v);
	cout << "\ninsert(idx, v):"<< endl; 
    ptr->add(0); ptr->add(1); ptr->add(2); ptr->add(3); 	ptr->add(4); ptr->add(5); ptr->add(6);
 	cout << ptr->to_string() << endl; 
	ptr->insert(3, 99);   cout << ptr->to_string() << endl; 
	ptr->insert(5, 199);  cout << ptr->to_string() << endl; 
	ptr->insert(0, 999); cout << ptr->to_string() << endl; 
	ptr->insert(ptr->size(), 1024); cout << ptr->to_string() << endl; 

	// test append(list);
	cout << "\nappend(list):"<< endl; 	
	ptr1->add_front(3); 
	ptr1->add_front(4); 
	ptr1->add_front(5); 
	ptr1->add_front(6);
    ptr->append(ptr1);
 	cout << ptr->to_string() << endl; 
	return 0; 
}
#endif