#include <iostream>
#include "treenode.h"
using namespace std; 

#ifdef MAIN
int main(){
	treenode<int> *a = new treenode<int>(1); 
	treenode<int> *b = new treenode<int>(2); 
	treenode<int> *c = new treenode<int>(3); 
	treenode<int> *d = new treenode<int>(4); 
	treenode<int> *e = new treenode<int>(5); 
	treenode<int> *f = new treenode<int>(6); 
	treenode<int> *g = new treenode<int>(7); 
	a->setLeft(b); 
	a->setRight(c); 
	b->setLeft(d);
    b->setRight(e); 
    c->setLeft(f); 
    c->setRight(g); 	
    cout << "Pre-Order Traversal : "<< a->preorder(a) << endl; 
	cout << "In-Order Traversal   : "<< a->inorder(a) << endl; 
	cout << "Post-Order Traversal: "<< a->postorder(a) << endl; 
	return 0; 
}
#endif