#define MAIN
#ifndef TREENODE_H
#define TREENODE_H
#include "to_string.h"
using namespace std; 
template <typename T> 
class treenode{
	public: 
	    treenode<T> *left; 
		treenode<T> *right; 
	    treenode(): left(NULL), right(NULL) {}
		treenode(T t){ left=NULL; right=NULL; object = t; }
		void setLeft(treenode<T> *le){ left = le; } 
		void setRight(treenode<T> *r){ right = r; }
		treenode<T> *getLeft(){ return left; }
		treenode<T> *getRight(){ return right; }
		bool hasLeft(){
			if (getLeft()!= NULL) return true; 
			else return false; 
		}
		bool hasRight(){
			if (getRight()!=NULL) return true; 
			else return false; 
		}
		string preorder(treenode<T> *top){
			string rtn = ""; 
			if (top != NULL ) {  
               rtn = rtn + top->to_string() + " ";      
               rtn = rtn + top->preorder( top->left );    
               rtn = rtn + top->preorder( top->right );   
		     }
			return rtn; 
		}
		string inorder(treenode<T> *top){
			string rtn = ""; 
			if (top != NULL ) {  
			   rtn = rtn + top->inorder( top->left );    
               rtn = rtn + top->to_string() + " ";      
               rtn = rtn + top->inorder( top->right );   
		     }
			return rtn; 
		}
		string postorder(treenode<T> *top){
			string rtn = ""; 
			if (top != NULL ) {  
			   rtn = rtn + top->postorder( top->left );    
			   rtn = rtn + top->postorder( top->right );   
               rtn = rtn + top->to_string() + " ";      
		     }
			return rtn; 
		}
		string to_string(){ return st::to_string(object); }
		T get(){ return object; }
	private: 
	    T object; 
}; 
#endif














