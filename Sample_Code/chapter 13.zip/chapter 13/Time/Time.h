#define MAIN   // comment this line out if not __main__ function
#ifndef TIME_H
#define TIME_H
#include <iostream>
#include <string> 
using  namespace  std;
/* to_string patch: 
*/
#include <sstream>
namespace st{
    template < typename T > std::string to_string( const T& n ){
        std::ostringstream stm ;
        stm << n ;
        return stm.str() ;
    }
}
//  Specification file (Time.h)
class  Time  	// Declares a  class data type
{			//  does not allocate memory
  public : 		// Five public function members
    Time(int  h , int  m , int  s) ;
	void  Increment ();
    void  Set(int h, int m, int s);
	int    GetHours();
    int	 GetMins(); 
	int    GetSecs(); 
	bool  Equal (Time   otherTime)  const;        
	bool  LessThan (Time   otherTime)  const;
	string to_string(); 
	bool operator==(const Time &rhs) const { return hrs == rhs.hrs && mins == rhs.mins && secs == rhs.secs; }

  private :	      // Three private data members
	   int  hrs;           
	   int  mins;          
	   int  secs;
};
#endif 


