#include <iostream>
#include "Time.h"
#include "ExtTime.h"
using namespace std; 

int main(){
ExtTime  thisTime ( 8, 35, 0, PST);
ExtTime  thatTime; // Default constructor called

string s1 = thatTime.to_string(); // Outputs 00:00:00  EST
cout << s1 <<  endl; 

thatTime.Set (16, 49, 23, CDT);   
string s2 =thatTime.to_string(); // Outputs 16:49:23  CDT
cout << s2 << endl;

thisTime.Increment();
thisTime.Increment();
string s3 = thisTime.to_string(); // Outputs 08:35:02  PST
cout << s3 << endl;

return 0; 	
}