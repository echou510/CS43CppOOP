//#define MAIN   // comment this line out if not __main__ function
#ifndef EXTTIME_H
#define EXTTIME_H
#include <iostream>
#include <string> 
#include  "time.h"
enum ZoneType{EST, CST, MST, PST, EDT, CDT, MDT, PDT};
//  Specification file (Time.h)
class  ExtTime: public Time 	// Declares a  class data type
{			//  does not allocate memory
  public : 		// Six public function members
    ExtTime(int hours, int minutes, int seconds, ZoneType  timeZone) ;
	ExtTime(); 	
    void Set(int hours, int minutes, int seconds, ZoneType  timeZone);	
	string GetTimeZoneString(); 
	ZoneType GetTimeZone(); 
	void SetZone(ZoneType z); 
	string to_string(); 
  private :	  
    ZoneType  zone; // Additional data member
};
#endif 


