#ifndef NAME_H
#define NAME_H
#include <iostream>
#include <string>
using  namespace  std;
/* to_string patch: 
*/
#include <sstream>
namespace st{
    template < typename T > std::string to_string( const T& n ){
        std::ostringstream stm ;
        stm << n ;
        return stm.str() ;
    }
}
class Name{
	public: 
	   Name(string first_name, string last_name);
	   Name(); 
	   string getName(); 
	   string getFirst(); 
	   string getLast(); 
	   void set(string first_name, string last_name); 
	   void setFirst(string first_name);
       void setLast(string last_name); 	   
	private: 
	   string first(""); 
	   string last(""); 
}; 
#endif  