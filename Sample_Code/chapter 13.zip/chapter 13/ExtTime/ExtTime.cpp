#include <iostream> 
#include   "exttime.h"  // Includes specification of the class
#include "time.h"
#include <string> 
using  namespace  std;
ZoneType ExtTime::GetTimeZone(){
	return zone; 
} 
string ExtTime:: GetTimeZoneString(){
	string rtn=""; 
	switch (zone){
	   case EST: rtn="EST";   break; 
	   case CST: rtn="CST";   break; 
	   case MST: rtn="MST";  break; 
	   case PST: rtn="PST";   break; 
	   case EDT: rtn="EDT";  break; 
	   case CDT: rtn="CDT";   break; 
	   case MDT: rtn="MDT";  break; 
	   case PDT: rtn="PDT";   break;
	}
	return rtn; 	 
}
void ExtTime::SetZone(ZoneType z){
	  zone = z; 
} 
ExtTime::ExtTime(int hours, int minutes, int seconds, ZoneType  timeZone) {
	SetHours(hours); 
	SetMins(minutes); 
	SetSecs(seconds); 
	SetZone(timeZone); 
}
ExtTime::ExtTime (){ zone  =  PDT;
} 	
void ExtTime::Set(int hours, int minutes, int seconds, ZoneType  timeZone){
	SetHours(hours); 
	SetMins(minutes); 
	SetSecs(seconds); 
	SetZone(timeZone); 
}
string ExtTime::to_string(){
	  string rtn = ""; 
	  rtn += "Time: " + st::to_string(GetHours()) + ":" + st::to_string(GetMins()) + ":" + st::to_string(GetSecs())+"-"+GetTimeZoneString(); 
	return rtn; 
}
#ifdef MAIN
int  main (){
    ExtTime  currentTime; // Declares two objects of Time
    ExtTime  endTime;
    bool  done  =  false;

    currentTime.Set (5, 30, 0, PDT);
    endTime.Set (5, 30, 5, PDT);
    while  (! done)  
    {
        currentTime.Increment ();
		cout<<  currentTime.to_string() << endl; 
		 if  (currentTime.Equal (endTime)) 
	         done  =  true;      
         if (currentTime == endTime)	 cout << "Program Finished" << endl; 
    };
}
#endif