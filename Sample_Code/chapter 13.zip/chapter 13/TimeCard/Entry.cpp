#include <iostream>
#include <string>
#include "Time.h"
#include "Name.h"
#include "Entry.h"
Entry::Entry(){}
Entry::Entry(Name n, Time t){
	name = n; 
	time = t; 
}
string Entry::NameStr(){
	return name.getName(); 
}
string Entry::TimeStr(){
	return time.to_string(); 
}
string Entry::to_string(){
	return NameStr()+" "+TimeStr(); 
}

#ifdef MAIN
int main(){
	Name eric("Eric", "Chou");
    Time   timestamp(5, 10, 15);
    Entry eric_day1(eric, timestamp); 
    cout << eric_day1.to_string();  	
	return 0; 
}
#endif
