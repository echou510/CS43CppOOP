#define MAIN
#ifndef TIMECARD_H
#define TIMECARD_H
#include  "Time.h"      
class TimeCard	{ 
    public:
            void  Punch(int   hours, int   minutes, int   seconds ) ;
            string  Print();
            TimeCard  ( long   idNum, int initHrs, int  initMins,  int initSecs ) ;
            TimeCard() ;
      private:
            long    id ;
            Time   timeStamp ;
} ;
#endif

