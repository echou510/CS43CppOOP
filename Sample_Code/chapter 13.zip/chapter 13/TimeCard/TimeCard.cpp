#include <iostream> 
#include <string>
#include "Time.h"
#include "TimeCard.h"
void  TimeCard::Punch(int   hours, int   minutes, int   seconds ) {
	  timeStamp.SetHours(hours);
	  timeStamp.SetMins(minutes); 
	  timeStamp.SetSecs(seconds); 
}
string TimeCard::Print(){ return st::to_string(id) +" "+timeStamp.to_string(); }
TimeCard ::TimeCard( long   idNum, int initHrs, int  initMins,  int initSecs )    
    :timeStamp (initHrs, initMins, initSecs) {
	id  =  idNum ;
}
TimeCard::TimeCard() {}

#ifdef MAIN
int main(){
	TimeCard eric_time(9002, 5, 10, 15); 
	cout << "Eric's Time Card = " << eric_time.Print() << endl; 
	return 0; 
}
#endif 