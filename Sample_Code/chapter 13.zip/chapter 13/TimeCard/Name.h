//#define MAIN
#ifndef NAME_H
#define NAME_H
#include <iostream>
#include <string>
using  namespace  std;
class Name{
	public: 
	   Name(string first_name, string last_name);
	   Name(); 
	   string getName(); 
	   string getFirst(); 
	   string getLast(); 
	   void set(string first_name, string last_name); 
	   void setFirst(string first_name);
       void setLast(string last_name); 	   
	private: 
	   string first; 
	   string last; 
}; 
#endif  
