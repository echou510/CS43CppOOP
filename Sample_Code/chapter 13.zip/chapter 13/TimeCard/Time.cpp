#include <iostream> 
#include   "time.h"  // Includes specification of the class
#include <string> 
using  namespace  std;
Time::Time (int  h=0 , int  m=0 , int  s=9) : hrs(h), mins(m), secs(s) {
	   hrs = h; 
	   mins = m; 
	   secs = s; 
}
Time::Time(){
}
void  Time::Increment (){
	secs++; 
	mins += secs/60; 
	secs  %= 60; 
	hrs   += mins/60; 
	mins %= 60; 
	hrs    %=24; 
}
int Time::GetHours(){ return hrs; }
int Time::GetMins(){ return mins; }
int Time::GetSecs(){return secs; }
void  Time::SetHours(int hours){
	hrs = hours; 
}
void  Time::SetMins(int minutes){
	mins = minutes; 
}
void   Time::SetSecs(int seconds){
	secs = seconds; 
}
void  Time::Set(int h, int m, int s) {
	 hrs = h; 
	 mins = m; 
	 secs = s; 
}
bool  Time::Equal (Time   otherTime) {
	int h1 = GetHours(); 
	int h2 = otherTime.GetHours(); 
    int m1 = GetMins(); 
	int m2 = otherTime.GetMins(); 
    int s1 = GetSecs(); 
	int s2 = otherTime.GetSecs(); 
    if (h1 == h2 &&  m1 == m2 && s1  == s2) return true; 
	return false; 
}        
bool  Time::LessThan (Time   otherTime) {
	int h1 = GetHours(); 
	int h2 = otherTime.GetHours(); 
    int m1 = GetMins(); 
	int m2 = otherTime.GetMins(); 
    int s1 = GetSecs(); 
	int s2 = otherTime.GetSecs(); 
	if (h1 < h2) return true; 
	 else if (h1 == h2){
		        if (m1 < m2) return true; 
				else if (m1 == m2){
					if (s1 < s2) return true; 
					else if (s1 == s2) return false; 
				            else return false;  }
				else return false; }
	 else return false; 
}
string Time::to_string(){
	string rtn = ""; 
	rtn += "Time: " + st::to_string(GetHours()) + ":" + st::to_string(GetMins()) + ":" + st::to_string(GetSecs()); 
	return rtn; 
}
#ifdef MAIN
int  main (){
    Time  currentTime; // Declares two objects of Time
    Time  endTime;
    bool  done  =  false;

    currentTime.Set (5, 30, 0);
    endTime.Set (5, 30, 5);
    while  (! done)  
    {
        currentTime.Increment ();
		cout<<  currentTime.to_string() << endl; 
		 if  (currentTime.Equal (endTime)) 
	         done  =  true;      
         if (currentTime == endTime)	 cout << "Program Finished" << endl; 
    };
}
#endif

