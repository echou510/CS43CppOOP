#define MAIN
#ifndef ENTRY_H
#define ENTRY_H
#include "Time.h"
#include "Name.h"
using namespace std; 

class Entry{
  public:
    string NameStr();
    string TimeStr();
    Entry();     // Default constructor
    Entry(Name, Time);    // Parameterized constructor 
	string to_string(); 
  private:
    Name name;
    Time time;
} ;
#endif