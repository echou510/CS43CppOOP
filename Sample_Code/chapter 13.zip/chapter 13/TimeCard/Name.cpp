#include <iostream>
#include "Name.h"
using namespace std; 

Name::Name(string first_name, string last_name){
	first = first_name; 
	last  = last_name; 
}
Name::Name(){}
string Name::getName(){ return first+" "+last; } 
string Name::getFirst(){ return first; }
string Name::getLast(){ return last; }
void Name::set(string first_name, string last_name){
	first = first_name; 
	last  = last_name; 
}
void Name::setFirst(string first_name){
	first = first_name; 
}
void Name::setLast(string last_name){
	last = last_name; 
}

#ifdef MAIN
int main(){
	Name eric("Eric", "Chou"); 
	cout << "getName=" << eric.getName() << endl; 
	cout << "getFirt=" << eric.getFirst() << endl; 
	cout << "getLast=" << eric.getLast() << endl; 
	eric.set("Eric Y.", "Chou Sr."); 
	cout << "getName=" << eric.getName() << endl; 
	cout << "getFirt=" << eric.getFirst() << endl; 
	cout << "getLast=" << eric.getLast() << endl; 
	return 0; 
}
#endif