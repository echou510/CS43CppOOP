//#define MAIN
#ifndef TIME_H
#define TIME_H
#include <iostream>
#include <string> 
#include <sstream>
namespace st{
    template < typename T > std::string to_string( const T& n ){
        std::ostringstream stm ;
        stm << n ;
        return stm.str() ;
    }
}
using  namespace  std;
//  Specification file (Time.h)
class  Time  	// Declares a  class data type
{			//  does not allocate memory
  public : 		// Five public function members
    Time(int  h , int  m , int  s) ;
	Time(); 
	void  Increment ();
    void  Set(int h, int m, int s);
	int    GetHours();
    int	 GetMins(); 
	int    GetSecs(); 
    void   SetHours(int hours);
    void   SetMins(int minutes); 
	void   SetSecs(int seconds); 
	bool  Equal (Time   otherTime) ;        
	bool  LessThan (Time   otherTime);
	string to_string(); 
	bool operator==(const Time &rhs) const { return hrs == rhs.hrs && mins == rhs.mins && secs == rhs.secs; }

  private :	      // Three private data members
	   int  hrs;           
	   int  mins;          
	   int  secs;
};
#endif 





