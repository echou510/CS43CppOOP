#include  <iostream>
#include <string>
#include  "slist.h"

using namespace std;
int  SortedList::size(){    
	  return  length;
}
bool  SortedList::isFull (){
	  return (length == MAX_LENGTH);
}
SortedList::SortedList (){
	  length = 0;
}
void  SortedList::insert (ItemType  item){
	  int index;
    // Find proper location for new element
    index  =  length - 1;
	while (index >= 0  &&  item < data[index] ){	
		  data[index + 1]  =  data[index];
		  index--;
     }	
	data[index+1] = item;
    length++;
}
bool  SortedList::isEmpty () {
	  return (length == 0);
}
bool SortedList::isPresent(ItemType item) {    
    bool found = false;
    int  position;
    BinSearch (item, found, position);
    return  found;
}
void  SortedList::BinSearch (ItemType  item,   bool&  found,  int&  position)  
{   
    int middle;
    int first  =  0;
    int last  = length - 1;
    found = false;
	  while (last >= first  &&   !found)
	  {	 middle = (first + last)/2; 

		 if (item  <  data[middle])     
		     last = middle - 1;	 
		 else if (item  >  data[middle])   	 
		    first = middle + 1;	 
		 else
		    found = true;	   	
     }
	  if  (found) 
		position = middle;
}

void  SortedList::remove (ItemType  item) {    
    bool found=false;	 
    int  position; 
	int  index;
	
	BinSearch (item, found, position);
	if (found){		
	   for (index = position; index < length - 1;  index++)
		      data[index ] = data[index  + 1];
        length--;
    }
}
void SortedList::reset(){
    currentPos = 0;
}
ItemType SortedList::getNextItem (){
    ItemType item;
    item = data[currentPos];
    if (currentPos == length - 1)
        currentPos = 0;
    else
        currentPos++;
    return item;    
}
void  SortedList::selSort () {   
  ItemType temp;
	  int passCount;
	  int sIndx;
	  int minIndx; 	// Index of minimum so far    
  for (passCount = 0; passCount < length - 1; passCount++){
		  minIndx = passCount;
   	  	   // Find index of smallest value left
		  for (sIndx = passCount + 1;  sIndx <  length; sIndx++)
     		if (data[sIndx] < data[minIndx])
			    minIndx = sIndx;
		  temp = data[minIndx];		// Swap 
		  data[minIndx] = data[passCount];
		  data[passCount] = temp;
	  }
}
string SortedList::to_string(){
	string rtn = ""; 
		for (int i=0; i<size(); i++){
		if (i==0) rtn +="["+st::to_string(data[i]);
        else if (i!=size()-1) rtn += ", "+st::to_string(data[i]);
		else rtn += ", "+st::to_string(data[i])+"]";
	}
	return rtn;
}
#ifdef MAIN
int main(){
	int a[9]= {2, 4, 5, 6, 1, 7, 8, 9, 0}; 
	SortedList lista; 
	for (int i=0; i<=9; i++){
		cout << a[i] << endl; 
		lista.insert(a[i]); 
	}
	cout << "Before Sorting:"<< lista.to_string() << endl;  
	lista.selSort(); 
	cout << "After Sorting:"<< lista.to_string() << endl;  
	return 0; 
}
#endif 

