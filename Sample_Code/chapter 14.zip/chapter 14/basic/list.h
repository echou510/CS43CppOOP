#define MAIN   // comment this line out if not __main__ function
#ifndef LIST_H
#define LIST_H
#include <iostream>
#include <string> 
using namespace std; 
#include <sstream>
namespace st{
    template < typename T > std::string to_string( const T& n ){
        std::ostringstream stm ;
        stm << n ;
        return stm.str() ;
    }
}
const  int  MAX_LENGTH  =  50;
typedef int ItemType;
class  List{						
public: 	          // Public member functions
    List();           // constructor
    bool isEmpty();
    bool isFull();              
    int  size(); // Returns length of list 
    void insert(ItemType  item); 	
    void remove(ItemType  item); 	
    bool isPresent(ItemType  item);
    void selSort();
    void reset();
    ItemType getNextItem ();  
	string to_string(); 
private:	      // Private data members
	int length;   // Number of values currently stored
	ItemType data[MAX_LENGTH]; 
    int  currentPos;  // Used in iteration       
};	
#endif 


