#include  <iostream>
#include <string>
#include  "list.h"

using namespace std;
int  List::size(){    
	  return  length;
}
bool  List::isFull (){
	  return (length == MAX_LENGTH);
}
List::List (){
	  length = 0;
}
void  List::insert (ItemType  item){
	  data[length] = item;
	  length++;
}
bool  List::isEmpty () {
	  return (length == 0);
}
bool List::isPresent(ItemType item) {    
    int index  =  0;
	  while (index < length && item != data[index])
		  index++;
    return  (index < length);
}
void  List::remove (ItemType  item) {    
    int  index  =  0;
    
    while (index < length  &&  item != data[index])
		  index++;
    if (index < length)
    {
     	  data[index] = data[length - 1];
		  length--;
    }
}
void List::reset(){
    currentPos = 0;
}
ItemType List::getNextItem (){
    ItemType item;
    item = data[currentPos];
    if (currentPos == length - 1)
        currentPos = 0;
    else
        currentPos++;
    return item;    
}
void  List::selSort () {   
  ItemType temp;
	  int passCount;
	  int sIndx;
	  int minIndx; 	// Index of minimum so far    
  for (passCount = 0; passCount < length - 1; passCount++){
		  minIndx = passCount;
   	  	   // Find index of smallest value left
		  for (sIndx = passCount + 1;  sIndx <  length; sIndx++)
     		if (data[sIndx] < data[minIndx])
			    minIndx = sIndx;
		  temp = data[minIndx];		// Swap 
		  data[minIndx] = data[passCount];
		  data[passCount] = temp;
	  }
}
string List::to_string(){
	string rtn = ""; 
		for (int i=0; i<size(); i++){
		if (i==0) rtn +="["+st::to_string(data[i]);
        else if (i!=size()-1) rtn += ", "+st::to_string(data[i]);
		else rtn += ", "+st::to_string(data[i])+"]";
	}
	return rtn;
}
#ifdef MAIN
int main(){
	int a[9]= {2, 4, 5, 6, 1, 7, 8, 9, 0}; 
	List lista; 
	for (int i=0; i<=9; i++){
		cout << a[i] << endl; 
		lista.insert(a[i]); 
	}
	cout << "Before Sorting:"<< lista.to_string() << endl;  
	lista.selSort(); 
	cout << "After Sorting:"<< lista.to_string() << endl;  
	return 0; 
}
#endif 

