#include <iostream>
#include <string>

using namespace std;
void odd(int x) throw (int) {
  if (x%2 == 0)
     throw 0; 
}
void even(int x) throw (string){
	string msg = "Not even"; 
	  if (x%2 != 0)
     throw msg; 
}
void f(int x){
	try{
	cout << "Begin TRY section\n";
	odd(x);
	cout << "End of TRY section\n";
	} 
	catch (...){ cerr << "***Error in f***\n"; }
	even(x);  // not handled here. 
}
main(){
  try{
	f(2); 
  }
  catch (string msg) { cerr << "main Error handler "<< msg << endl; }  
  catch (...){ cerr << "***main Error handler ***\n"; }
  
  try{
	f(3); 
  }
  catch (string msg) { cerr <<  "main Error handler "<< msg  << endl; }  
  catch (...){ cerr << "***main Error handler ***\n"; }
}

