#include <iostream>
#include <memory>
using namespace std; 
//using std::auto_ptr; // auto_ptr class definition

class Integer {    
    public:
       Integer( int i = 0 ): value( i ){
            cout << "Constructor for Integer " << value << endl;
       } 
       ~Integer(){
             cout << "Destructor for Integer " << value << endl;
           } 
       void setInteger( int i ){  value = i; } 
      int getInteger() const { return value; } 
    private:
       int value; 
};  // end class Integer

int main(){
       cout << "Creating an auto_ptr object that points to an " << "Integer\n";
       // "aim" auto_ptr at Integer object                  
       auto_ptr< Integer> ptrToInteger( new Integer( 7 ) );    
       cout << "\nUsing the auto_ptr to manipulate the Integer\n";    
       // use auto_ptr to set Integer value
       ptrToInteger->setInteger( 99 );         
       // use auto_ptr to get Integer value
       cout << "Integer after setInteger: " 
               << ( *ptrToInteger ).getInteger()
              << "\n\nTerminating program" << endl;    
       return 0;
}  // end main


