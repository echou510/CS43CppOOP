#include <iostream>
#include <exception>
#include <stdexcept>
using namespace std; 
             
class DivideByZeroException : public runtime_error {              
	public:                                                       
            DivideByZeroException()  : runtime_error( "attempted to divide by zero" ) {}                                                                 
};    

// perform division and throw DivideByZeroException object if 
// divide-by-zero exception occurs
double quotient( int numerator, int denominator ){
    if ( denominator == 0 )  throw DivideByZeroException(); 
    return static_cast< double >( numerator ) / denominator;
 }  // end function quotient

int main(){
    int number1;     // user-specified numerator
    int number2;    // user-specified denominator
    double result;   // result of division

    cout << "Enter two integers (end-of-file to end): ";

	// enable user to enter two integers to divide
    while ( cin >> number1 >> number2 ) {
		try {                                                     
			result = quotient( number1, number2 );                 
			cout << "The quotient is: " << result << endl;         
        }                                                    
		catch ( DivideByZeroException &divideByZeroException ) {  
				cout << "Exception occurred: "  << divideByZeroException.what() << endl;                                                                   
		}                                        
        cout << "\nEnter two integers (end-of-file to end): ";
    } 
   cout << endl;
   return 0; 
}  


