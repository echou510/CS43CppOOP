#define LEN 50
#include <iostream>
using namespace std; 
     
int main(){
   double *ptr[LEN];
   // allocate memory for ptr
   for ( int i = 0; i < LEN; i++ ) {
       ptr[ i ] = new double[50000000];
          // new returns 0 on failure to allocate memory
          if ( ptr[i] == 0 ) {
             cout << "Memory allocation failed for ptr[ " 
                  << i << " ]\n";
             break;
          } // end if
          // successful memory allocation
          else
             cout << "Allocated 5000000 doubles in ptr[ " 
                  << i << " ]\n";
       } // end for
       return 0;
}  // end main



