#define LEN 50
#include <iostream>
#include <new> // standard operator new
using namespace std; 
 
int main(){
    double *ptr[ LEN ];
    // attempt to allocate memory
    try {
     // allocate memory for ptr[ i ]; new throws bad_alloc 
  	 // on failure
     for ( int i = 0; i < LEN; i++ ) {
             ptr[ i ] = new double[50000000];
             cout << "Allocated 5000000 doubles in ptr[ " 
                  << i << " ]\n";
          }  
       } // end try
       // handle bad_alloc exception
       catch ( bad_alloc &memoryAllocationException ) {
          cout << "Exception occurred: " 
               << memoryAllocationException.what() << endl;
    } // end catch       
    return 0;
}  // end main



