#ifndef STUDENT_H
#define STUDENT_H
#include <iostream>
#include <sstream>
#include <string>
using namespace std; 

class Student{
  public: 
    Student(string n): name(n){ }
    string getName(){ return name; }
    string toString2(){ return name; }                    // member function 
    friend string toString3(Student s){ return s.name;}   // friendship function: Utility Function
                                                          // access to private and protected data field 
    friend ostream &operator<<(ostream &out, Student s){
	  out << s.name; 
	  return out; 
    }
	friend istream &operator>>(istream &in, Student &s){ 
	   char buf[256]; 
	   in >> buf;      // c-string
	   string n(buf);  // convert c-string to string stirng n(buf): convert c-string to string, n.c_str opposite. 
	   s.name = n;     // assign string to s.name
	   return in; 
	}
  private: 
    string name; 
}; 
// global function 
string toString1(Student s){
	return s.getName(); 
} 
#endif 
