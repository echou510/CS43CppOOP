#include <iostream>
#include "Student.h"
using namespace std; 

int main(int argc, char** argv) {
	Student a("Eric Chou");
	cout << toString1(a) << endl;  
    cout << a.toString2() << endl; 
    cout << toString3(a) << endl; // some what like Java class function Math.round(number); 
                                  // no specifier
    cout << a << endl; 
    
    Student b(""); 
    cout << "Enter a new student name: "; 
    cin >> b;  
    cout << b << endl; 
    
	return 0;
}
