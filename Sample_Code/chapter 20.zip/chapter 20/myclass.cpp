#include <iostream>

using namespace std; 
struct myclass { 
    int i;
	myclass(int x){ i=x; }
};

ostream &operator<<(ostream &os, const myclass  &m) { 
    return os << m.i;
}

int main() { 
    myclass x(10);

    cout << x;
    return 0;
}