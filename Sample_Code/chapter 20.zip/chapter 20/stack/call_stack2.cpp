#include <iostream>
using namespace std; 

#include "stack.h"  // Stack class template definition
    
// function template to manipulate Stack< T >                
template< class T >                                          
void testStack(Stack< T > &theStack,  T value,  T increment,  const char *stackName ){                                                            
    cout << "\nPushing elements onto " << stackName << '\n';                                                 
    while ( theStack.push( value ) ) {                        
       cout << value << ' ';                                  
       value += increment;                                                                                               
    } // end while                                            
    cout << "\nStack is full. Cannot push " << value          
         << "\n\nPopping elements from " << stackName << '\n';                                                              
    while ( theStack.pop( value ) )                           
       cout << value << ' ';                                                                                                
    cout << "\nStack is empty. Cannot pop\n";                 
} // end function testStack                                  
   
int main(){
   Stack< double > doubleStack( 5 );   
   Stack< int > intStack;
   testStack( doubleStack, 1.1, 1.1, "doubleStack" );
   testStack( intStack, 1, 1, "intStack" );          
   return 0;  
} // end main


