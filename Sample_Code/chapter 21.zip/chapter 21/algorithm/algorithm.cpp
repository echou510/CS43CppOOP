#include <iostream>
#include <iterator>
#include <algorithm>  // algorithm definitions
#include <vector>     // vector class-template definition
using namespace std; 
bool greater10( int value ) { return value > 10; } // end function greater10

int main(){
       const int SIZE = 10;
       int a[ SIZE ] = { 10, 2, 17, 5, 16, 8, 13, 11, 20, 7 };    
       vector< int > v( a, a + SIZE );
       ostream_iterator< int > output( cout, " " );   
       cout << "Vector v contains: ";
       copy( v.begin(), v.end(), output );
       
       // locate first occurrence of 16 in v          
       vector< int >::iterator location;         
       location = find( v.begin(), v.end(), 16 );
       if ( location != v.end() )  cout << "\n\nFound 16 at location " << ( location - v.begin() );
       else  cout << "\n\n16 not found";
       // locate first occurrence of 100 in v          
       location = find( v.begin(), v.end(), 100 );
    
       if ( location != v.end() ) 
          cout << "\nFound 100 at location "  << ( location - v.begin() );
       else 
          cout << "\n100 not found";
    
       // locate first occurrence of value greater than 10 in v 
       location = find_if( v.begin(), v.end(), greater10 );
       if ( location != v.end() ) 
          cout << "\n\nThe first value greater than 10 is " << *location << "\nfound at location "  << ( location - v.begin() );
       else 
          cout << "\n\nNo values greater than 10 were found";
    
       // sort elements of v
       sort( v.begin(), v.end() );
       cout << "\n\nVector v after sort: ";
       copy( v.begin(), v.end(), output );
       // use binary_search to locate 13 in v
       if ( binary_search( v.begin(), v.end(), 13 ) )
          cout << "\n\n13 was found in v";
       else
          cout << "\n\n13 was not found in v";

    // use binary_search to locate 100 in v
    if ( binary_search( v.begin(), v.end(), 100 ) ) cout << "\n100 was found in v";
    else cout << "\n100 was not found in v";
    cout << endl;
    return 0;
} // end main


