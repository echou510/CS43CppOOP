#include <iostream>
#include <iterator>
#include <vector>      // vector class-template definition
#include <algorithm>   // copy algorithm
#include <numeric>     // accumulate algorithm
#include <functional>  // binary_function definition
using namespace std; 

int sumSquares( int total, int value ) {   return total + value * value; } 

template< class T > 
class SumSquaresClass : public binary_function< T, T, T > {
    public:                                                          
       const T operator()( const T &total, const T &value )   {  return total + value * value;  } 
}; // end class SumSquaresClass 

int main(){
       const int SIZE = 10;
       int array[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
       int result = 0;
       vector< int > integers( array, array + SIZE );
       ostream_iterator< int > output( cout, " " );
       cout << "vector v contains:\n";
       copy( integers.begin(), integers.end(), output );
    
       // calculate sum of squares of elements of vector integers 
       // using binary function sumSquares                        
       result = accumulate( integers.begin(), integers.end(), 0, sumSquares );                                        
    
       cout << "\n\nSum of squares of elements in integers using "
            << "binary\nfunction sumSquares: " << result;
       // calculate sum of squares of elements of vector integers 
       // using binary-function object                            
       result = accumulate( integers.begin(), integers.end(),  0, SumSquaresClass< int >() );                          

       cout << "\n\nSum of squares of elements in integers using " << "binary\nfunction object of type " 
            << "SumSquaresClass< int >: " << result << endl;    
     return 0;
} // end main