#include <vector>
#include <iostream>
using namespace std; 
int main(){
  int arr[] = { 12, 3, 17, 8 };  // standard C array
  vector<int> v(arr, arr+4);  // initialize vector with C array 
  while ( ! v.empty()) // until vector is empty
  {
      cout << v.back() << " ";   // output last element of vector
      v.pop_back();                 // delete the last element
  }
  cout << endl;
  return 0; 
}

