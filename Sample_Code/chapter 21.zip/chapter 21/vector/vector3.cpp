#include <iostream>
#include <vector>  // vector class-template definition
using namespace std; 
template <class T>
void printVector(vector<T> const& v) {
	typename vector<T>::const_iterator i;   
	for (i= v.begin();  i != v.end();   i++ )                           
          cout << *i << ' ';     cout << endl; 	
}

template <class T>
void printV(vector<T> & v) {
	typename vector<T>::iterator i;   
	for (i= v.begin();  i != v.end();   i++ )                           
          cout << *i << ' ';     cout << endl; 	
}

int main(){
       const int SIZE = 6;   
       int array[ SIZE ] = { 1, 2, 3, 4, 5, 6 };
       vector<int> integers;
    
       cout << "The initial size of integers is: "  << integers.size() << endl; 
       cout << "The initial capacity of integers is: " << integers.capacity() << endl;
	   integers.push_back( 2 ); 
       integers.push_back( 3 );
       integers.push_back( 4 );
       cout << "The size of integers is: " << integers.size() << endl; 
       cout << "The capacity of integers is: " << integers.capacity() << endl; 
       cout << "\nOutput array using pointer notation: ";
	   
       for ( int *ptr = array; ptr != array + SIZE; ++ptr )
          cout << *ptr << ' ' ;   cout << endl; 
       cout << "Output vector using const iterator notation: ";
       printVector( integers );
	   cout << "Output vector using iterator notation: ";
	   printV( integers );
	   
	   cout << "Reversed contents of vector integers: ";
	   typename vector< int >::reverse_iterator ri;   
       for ( ri = integers.rbegin();  ri != integers.rend(); ++ri )                 
          cout << *ri << ' ';       cout << endl;
       
	   return 0;
} // end main



    
            
