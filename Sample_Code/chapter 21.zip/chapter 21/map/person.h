#ifndef PERSON_H
#define PERSON_H
#include <string> 
#include <sstream>
namespace st{
    template < typename T > std::string to_string( const T& n ){
        std::ostringstream stm ;
        stm << n ;
        return stm.str() ;
    }
}

using namespace std; 
class person {
    private:
      string lastName;
      string firstName;
      long long phoneNumber;
    public:
       person(string lana, string fina, long long pho)  {
		    lastName = lana; 
			firstName= fina;  
			phoneNumber = pho; 
		}
    bool operator<(const person& p);
    bool operator==(const person& p);
	string to_string(){ return firstName + " " + lastName + ": " + st::to_string(phoneNumber); }
}; 
#endif 