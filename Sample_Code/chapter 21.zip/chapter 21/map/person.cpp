#include <iostream>
#include <set> 
#include "person.h"
using namespace std; 

int main(){
   person p1("Neuville", "Oliver", 5103452348LL);
   person p2("Kirsten", "Ulf", 5102782837LL);
   person p3("Larssen", "Henrik", 8904892921LL);
   multiset<person, less<person>> persSet;
   multiset<person, less<person>>::iterator iter;
   persSet.insert(p1); 
   persSet.insert(p2);
   persSet.insert(p3);
   
    //for (iter = persSet.begin(); iter !=persSet.end(); iter++)
     //cout << *iter << endl;
   return 0; 
}