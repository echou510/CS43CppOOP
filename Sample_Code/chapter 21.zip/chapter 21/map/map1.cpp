#include <iostream>
#include <iterator>
#include <map>
using namespace std; 

int main(){
  string names[]= {"Ole", "Hedvig", "Juan", "Lars", "Guido", "Patric", "Maria", "Ann"};
  int numbers[]= {75643, 83268, 97353, 87353, 19988, 76455, 77443,12221};
  map<string, int, less<string> > phonebook;
  map<string, int, less<string> >::iterator iter;
  for (int j=0; j<8; j++)
     phonebook[names[j]]=numbers[j];  // initialize map phonebook
  for (iter = phonebook.begin(); iter !=phonebook.end(); iter++)
     cout << (*iter).first << " : " << (*iter).second << endl;
  cout << "Lars phone number is " << phonebook["Lars"] << endl;
  return 0; 
}


