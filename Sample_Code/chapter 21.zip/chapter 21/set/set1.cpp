#include<iostream>
#include <set>
#include<iterator>
using namespace std; 
int main(){
  string names[] = {"Ole", "Hedvig", "Juan", "Lars", "Guido"}; 
  set<string, less<string> > nameSet(names,names+5);
  // create a set of names in which elements are alphabetically ordered string is the key and the object itself
  nameSet.insert("Patric"); // inserts more names
  nameSet.insert("Maria");
  nameSet.erase("Juan"); // removes an element
  set<string, less<string> >::iterator iter; // set iterator
  string searchname; 
  cout << "Enter a search name: "; 
  cin >> searchname;
  iter=nameSet.find(searchname);  // find matching name in set
  if (iter == nameSet.end())    	     // check if iterator points to end of set
      cout << searchname << " not in set!" <<endl;
  else
      cout << searchname << " is in set!" <<endl;
  cout << "\n\nPart 2: " << endl; 
  string names1[] = {"Ole", "Hedvig", "Juan", "Lars", "Guido", "Patric", "Maria", "Ann"}; 
  set<string, less<string> > nameSet1(names1,names1+7);
  set<string, less<string> >::iterator iter1; // set iterator
  iter1=nameSet1.lower_bound("G"); 
  // set iterator to lower start value "G"
  cout << "Lower Bound:" << *iter1 << endl; 
  iter1 = nameSet1.upper_bound("P"); 
  cout << "Upper Bound:" << *iter1 << endl;   
  iter1=nameSet1.lower_bound("G"); 
  while (iter1 != nameSet1.upper_bound("P")  )
   { cout << *iter1++ << endl;  }
  // displays Lars, Maria, Ole
  return 0; 
}