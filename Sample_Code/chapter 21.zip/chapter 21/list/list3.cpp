#include <iostream> 
#include <list> 
using namespace std; 
template<class T> 
void print(list<T> &list){
     for (int i: list) cout << i << " "; 
	 cout << endl; 
}

int main(){
  int arr1[]= { 6, 4, 9, 1, 7 };
  int arr2[]= { 4, 2, 1, 3, 8 };
  list<int>  l1(arr1, arr1+5); // initialize l1 with arr1
  list<int>  l2(arr2, arr2+5); // initialize l2 with arr2
  l1.sort();  // l1 = {1, 4, 6, 7, 9}
  l2.sort(); // l2= {1, 2, 3, 4, 8 }
  l1.merge(l2);  // merges l2 into l1 
  print(l1); 
  return 0; 
}

