#include <iostream> 
#include <list>
using namespace std; 
int main(){
  int arr1[]= { 1, 3, 5, 7, 9 };
  int arr2[]= { 2, 4, 6, 8, 10 };
  list<int>  l1(arr1, arr1+5); // initialize l1 with arr1
  list<int>  l2(arr2, arr2+5); // initialize l2 with arr2
  copy(l1.begin(), l1.end(), l2.begin()); 
  for (int i: l2){  // simple for-each loop 
	 cout << i << " "; 
  }
  return 0; 
}


