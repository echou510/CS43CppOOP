#include <iostream> 
#include <list> 
using namespace std; 
template<class T> 
void print(list<T> &list){
     for (int i: list) cout << i << " "; 
	 cout << endl; 
}

int main(){
  int arr1[]= { 1, 3, 5, 7, 9 };
  int arr2[]= { 2, 4, 6, 8, 10 };
  list<int>  l1(arr1, arr1+5); // initialize l1 with arr1
  list<int>  l2(arr2, arr2+5); // initialize l2 with arr2
  // adds contents of l1 to the end of l2 = { 2, 4, 6, 8, 10, 1, 3, 5, 7, 9  }
  copy(l1.begin(), l1.end(), back_inserter(l2));  // use back_inserter 
  print(l2); 
  // adds contents of l1 to the front of l2 = { 9, 7, 5, 3, 1, 2, 4, 6, 8, 10 }
  copy(l1.begin(), l1.end(), front_inserter(l2));  // use front_inserter 
  print(l2); 
  // adds contents of l1 at the ”old” beginning of l2 = { 1, 3, 5, 7, 9, 2, 4, 6, 8, 10 }
  copy(l1.begin(), l1.end(), inserter(l2, l2.begin())); 
  print(l2); 
  return 0; 
 }
 
 