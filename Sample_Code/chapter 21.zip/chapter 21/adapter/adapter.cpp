#include <iostream>
#include <stack>   // stack adapter definition
#include <vector>  // vector class-template definition
#include <list>    // list class-template definition
using namespace std; 
template< class T >void popElements( T &stackRef ){
       while ( !stackRef.empty() ) {
          cout << stackRef.top() << ' ';  // view top element  
          stackRef.pop();                 // remove top element
      } // end while
} // end function popElements

int main(){
       // stack with default underlying deque
       std::stack< int > intDequeStack;          
       // stack with underlying vector                      
       std::stack< int, std::vector< int > > intVectorStack;    
       // stack with underlying list                    
       std::stack< int, std::list< int > > intListStack;
       // push the values 0-9 onto each stack 
       for ( int i = 0; i < 10; ++i ) {
          intDequeStack.push( i ); 
          intVectorStack.push( i );
          intListStack.push( i );      
       } 
       // display and remove elements from each stack
       cout << "Popping from intDequeStack: ";
       popElements( intDequeStack );
       cout << "\nPopping from intVectorStack: ";
       popElements( intVectorStack );
       cout << "\nPopping from intListStack: ";
       popElements( intListStack );
       cout << endl;
    return 0;
} // end main






