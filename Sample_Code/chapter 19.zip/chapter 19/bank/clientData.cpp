#include <iostream>
#include <cstring>
#include "clientData.h"
using std::string;         
// default ClientData constructor
ClientData::ClientData( int accountNumberValue,  string lastNameValue, string firstNameValue,
                                              double balanceValue ){
       setAccountNumber( accountNumberValue );
       setLastName( lastNameValue );
       setFirstName( firstNameValue );
       setBalance( balanceValue );
} // end ClientData constructor
    
// get account-number value
int ClientData::getAccountNumber() const{
       return accountNumber;
} // end function getAccountNumber
// set account-number value
void ClientData::setAccountNumber( int accountNumberValue ){
       accountNumber = accountNumberValue;    
} // end function setAccountNumber
    
// get last-name value
string ClientData::getLastName() const{
       return lastName;
    
} // end function getLastName
    
// set last-name value
void ClientData::setLastName( string lastNameString ){
       // copy at most 15 characters from string to lastName
       const char *lastNameValue = lastNameString.data();
       int length = strlen( lastNameValue );
       length = ( length < 15 ? length : 14 );
       strncpy( lastName, lastNameValue, length );    
       // append null character to lastName
       lastName[ length ] = '\0';
} // end function setLastName
    
// get first-name value
string ClientData::getFirstName() const{
       return firstName;    
} // end function getFirstName
    
// set first-name value
void ClientData::setFirstName( string firstNameString ){
       // copy at most 10 characters from string to firstName
       const char *firstNameValue = firstNameString.data();
       int length = strlen( firstNameValue );
       length = ( length < 10 ? length : 9 );
       strncpy( firstName, firstNameValue, length );    
       // append new-line character to firstName
       firstName[ length ] = '\0';   
} // end function setFirstName

// get balance value
double ClientData::getBalance() const{
       return balance;
} // end function getBalance
    
// set balance value
void ClientData::setBalance( double balanceValue ){
       balance = balanceValue;    
} // end function setBalance
