#ifndef CLIENTDATA_H
#define CLIENTDATA_H
#include <iostream>
using std::string;
class ClientData { 
    public:    
       ClientData( int = 0, string = "", string = "", double = 0.0 );   // default ClientData constructor
       void setAccountNumber( int );    // accessor functions for accountNumber
       int getAccountNumber() const;
       void setLastName( string );          // accessor functions for lastName
       string getLastName() const;
       void setFirstName( string );         // accessor functions for firstName
       string getFirstName() const;    
       void setBalance( double );            // accessor functions for balance
       double getBalance() const;
    
    private:
       int accountNumber;
       char lastName[15];
       char firstName[10];
       double balance;    
}; // end class ClientData
#endif



