#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
using namespace std; 

int main(){	  
  ifstream fin;
  fin.open("usdeclar.txt");

  stringstream strStream;
  strStream << fin.rdbuf();                  //read the file in buffer mode into a stringstream strStream
  string str = strStream.str();               //str holds the content of the file

  cout << str << endl;                               //you can do anything with the string!!!	
  return 0; 
}


