#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
using namespace std;

int main(){
  ifstream fin("usdeclar.txt");

  if (fin.fail()) {
    cerr << "Unable to open file for reading." << endl;
    exit(1);
  }

  string token;
  while (fin >> token) {
    cout << "Token: " << token << endl;
  }
  
  fin.close();
  return 0;
}