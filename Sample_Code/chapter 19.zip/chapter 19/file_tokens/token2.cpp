#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <cctype>
#include <vector> 
using namespace std;

string trim(const string& str)
{
    size_t first = str.find_first_not_of(' ');
    if (string::npos == first)
    {
        return str;
    }
    size_t last = str.find_last_not_of(' ');
    return str.substr(first, (last - first + 1));
}

vector<string> split(const string &s, char delim) {
    stringstream ss(s);
    string item;
    vector<string> tokens;
    while (getline(ss, item, delim)) {
        tokens.push_back(item);
    }
    return tokens;
}

int main(){
  ifstream fin("usdeclar.txt");
  if (fin.fail()) {
    cerr << "Unable to open file for reading." << endl;
    exit(1);
  }
  string text("");
  string token;
  
  int count = 0; 
  while (fin >> token) {
    // remove non-letter, no-space letters. 
	string str("");
    for (int i=0; i<token.length(); i++){
		 if (!isalpha(token[i]) && token[i] != ' ') str += ' '; 
		 else str  += tolower(token[i]); 
	}
    str = trim(str); 	
	text += str + " "; 
  } 
  
  vector <string> wlist = split(text, ' '); 
  vector <string> wlist2; 
  for(int i=0; i<wlist.size(); i++) { 
       if (wlist[i].length() != 0) { wlist2.push_back(wlist[i]);  cout << wlist[i] << " " ;}
	}
	cout << endl; 
	cout << "Word List Count with Spaces = "<< wlist.size()<< endl; 
	cout <<  "Word List Count without Spaces = "<< wlist2.size() << endl; 
  
  fin.close();
  return 0;
}


