#include <iostream> 
#include <fstream>
 #include <iomanip>
 #include <cstdlib> // exit prototype
using namespace std; 
using std::ios;
using std::cerr;
using std::fixed;
using std::showpoint;
void outputLine( int account, const char * const name,  double balance ){
       cout << left << setw( 10 ) << account << setw( 13 ) << name
               << setw( 7 ) << setprecision( 2 ) << right << balance << endl; 
} // end function outputLine

int main(){
   int account;
   char name[ 30 ];
   double balance;   
   // ifstream constructor opens the file          
   ifstream inClientFile( "clients.dat", ios::in );   
   // exit program if ifstream could not open file
   if ( !inClientFile ) {
          cerr << "File could not be opened" << endl;
          exit( 1 );    
   } // end if
  
    cout<<left<<setw(10)<<"Account"<<setw(13)<<"Name"<<"Balance"<<endl<<fixed<<showpoint;
    while (inClientFile >> account >> name >> balance) outputLine( account, name, balance );
    return 0; // ifstream destructor closes the file    
} // end main


