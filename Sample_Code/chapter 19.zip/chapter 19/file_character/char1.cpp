#include <iostream>
#include <fstream>
using namespace std; 

int main(){
  char ch;
  fstream fin("usdeclar.txt", fstream::in);
  while (fin >> noskipws >> ch) {
    cout << ch; // Or whatever
  }
  return 0; 
}

