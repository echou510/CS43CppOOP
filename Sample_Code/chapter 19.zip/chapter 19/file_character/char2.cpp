#include <iostream>
#include <fstream>
#include <string>
using namespace std; 

int main(){	  
    fstream fin("usdeclar.txt", fstream::in);
    char ch;
	int count = 0; 
    string text(""); 
    while (fin.get(ch)){
		 if (!count) text += ch;
         else text += " " + ch; 		 
    }
	cout << text; 
	return 0; 
}

