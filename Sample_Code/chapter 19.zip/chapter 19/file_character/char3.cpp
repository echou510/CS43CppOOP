#include <iostream>
#include <fstream>
#include <string>
using namespace std; 

int main(){	  
    fstream fin("usdeclar.txt", fstream::in);
    char ch;
    while (fin.get(ch)){
        cout << ch; 	 
    }
	return 0; 
}


