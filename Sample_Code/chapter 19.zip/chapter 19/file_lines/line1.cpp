#include <iostream>
#include <fstream>
#include <string>
using namespace std; 

int main(){	  
    ifstream fin("usdeclar.txt", fstream::in);
    char ch;
	int count = 0; 
	string line; 
    while (getline(fin, line)){
		 cout << "Line " << ++count << ": " << line << endl;  		 
    } 
	return 0; 
}


