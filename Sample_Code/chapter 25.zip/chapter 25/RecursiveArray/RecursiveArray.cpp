#include <iostream>
using namespace std; 

int  Sum(const int a[], int low, int high){
    if (low == high) // Base case
        return  a [low];
    else                // General case
        return  a [low] + Sum(a, low + 1, high);
} 	

int LinearSearch(const int a[], int low, int high, int key){
    if  (a [low] == key) // Base case
        return low; 
    else if (low == high) // Second base case
        return -1;
    else                   // General case
        return LinearSearch(a, low + 1, high, key);
}

int BinarySearch (const int a[], int low, int high, int key) {            
    int  mid;
    if  (low > high) 	               	
        return -1;                              
    else{
        mid = (low + high) / 2;
        if (a [mid] == key)
            return mid;
        else if (key < a[mid]) // Look in lower half 
            return BinarySearch(a, low, mid-1, key);
        else  // Look in upper half
			return BinarySearch(a, mid+1, high, key);
    }
} 

int Minimum(const int a[], int size){
	if ( size == 1 ) 	                     //  base case
		return  a [ 0 ] ;
	else{                                   //  general case
        int  y = Minimum ( a, size - 1 );	
		if (y < a [size - 1])
            return  y ;
        else
            return a[size -1];
    }
}

int main(int argc, char** argv){
	int a[10] = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
	int b[10] = {3, 6, 7, 8, 4, 5, 9, 0, 1, 2}; 
	cout << Sum(a, 0, 9)<< endl; 
	cout << LinearSearch(b, 0, 9, 8)<< endl; 
	cout << BinarySearch(a, 0, 9, 30)<< endl;
	cout << Minimum(b, 10);  
	return 0;
}
