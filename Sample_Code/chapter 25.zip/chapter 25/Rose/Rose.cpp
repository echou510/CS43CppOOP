#include <iostream>
using namespace std; 
int  Rose (int  n){
    if  (n == 1)  // Base case
        return  0;
    else            // General case
        return (1 + Rose(n / 2));
}

int main(int argc, char** argv) {
	cout << Rose(25) << endl; 
	return 0;
}


