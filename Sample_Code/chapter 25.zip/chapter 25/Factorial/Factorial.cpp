#include <iostream>
using namespace std; 

// Pre: number is assigned and number >= 0
int   Factorial ( int   number)	{
    if  (number == 0)	// Base case
		   return  1;
	  else			     // General case	
		   return  
          number * Factorial (number - 1);
}

int main(int argc, char** argv) {
	cout << Factorial(5) << endl; 
	return 0;
}


