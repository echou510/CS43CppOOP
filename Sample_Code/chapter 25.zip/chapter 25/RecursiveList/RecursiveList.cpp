#include <iostream>
using namespace std; 
typedef  char  ComponentType;
struct  NodeType{
  ComponentType  component;
  NodeType*      link;
  NodeType(ComponentType c, NodeType* ptr):component(c), link(ptr){}
}; 

// Pre:  head points to an element of a list
// Post: All elements of list pointed to by head have
//   been printed in reverse order.
void  RevPrint (NodeType*   head){
    if (head != NULL){		    // General case	
        RevPrint (head-> link); // Process the rest
        // Print currrent     
        cout << head->component << endl; 	
    } 
	  // Base case : if the list is empty, do nothing
}

int main(int argc, char** argv) {
	NodeType*  head;
    NodeType *a = new NodeType('A', NULL);
    NodeType *b = new NodeType('B', NULL);
    NodeType *c = new NodeType('C', NULL);
    NodeType *d = new NodeType('D', NULL);
    NodeType *e = new NodeType('E', NULL);
	a->link = b; 
	b->link = c; 
	c->link = d; 
	d->link = e; 
	
	head = a; 
	RevPrint(head); 	 
	return 0;
}


