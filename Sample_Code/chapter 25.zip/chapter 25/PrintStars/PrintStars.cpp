#include <iostream>
using namespace std; 

//   Prints n asterisks, one to a line
//   Precondition:  n is assigned  
//   Postcondition: 
//       IF n > 0, call PrintSars
//       ELSE n stars have been written
void  PrintStars (/* in */  int   n){
    if  (n > 0)  // General case
    {	
        cout  << "*" <<  endl;
        PrintStars (n - 1);
    }
	  // Base case is empty else-clause	
}

int main(int argc, char** argv) {
	PrintStars(10); 
	return 0;
}


