#include <iostream>
using namespace std; 

// Computes the sum of the numbers from 1 to
//  n by adding n to the sum of the numbers
//  from 1 to (n-1)
// Precondition: n is assigned && n > 0
// Postcondition: Return value == sum of
//  numbers from 1 to n
int   Summation (/* in */  int   n)	
{
    if  (n == 1)	// Base case
		   return  1;
	  else			// General case	
		   return (n + Summation (n - 1));
}

int main(int argc, char** argv) {
	cout << Summation(10) << endl; 
	return 0;
}


