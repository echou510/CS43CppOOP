#include <iostream>
using namespace std; 
void Print(const int data[], int first, int last )
{
	  if (first <= last){	// Recursive case
		cout << data[first] << endl;
		Print(data, first+1, last);
	  }
	  // Empty else-clause is the base-case
}

int main(int argc, char** argv) {
	int data[3] = {0, 1, 2}; 
	Print(data, 0, 2); 
	return 0;
}


