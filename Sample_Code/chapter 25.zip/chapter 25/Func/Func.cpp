#include <iostream>
using namespace std; 

//  Pre:  Assigned(a)  &&  Assigned(b)
//  Post: Return value == ??
int Func (/* in */  int  a, /* in */  int  b){
    int  result;
    if  (b == 0)      // Base case
        result = 0;
    else if  (b > 0) // First general case
        result = a + Func (a, b - 1);   
          // Say location 50
    else    	    // Second general case
        result = Func (- a, - b);              
          // Say location 70
    return  result;           
} 	

int main(int argc, char** argv) {
	cout << Func(-5, -3) << endl ; 
	cout << Func(5, -3) << endl ; 
	return 0;
}


