#include <iostream>
using namespace std; 
// Simulates a familiar integer operator
// Precondition: a is assigned && a > 0
//	&&  b is assigned  &&    b >= 0
// Postcondition: Return value  ==   ???
int Find(/* in */ int b, /* in */ int a){
	cout << "Find("<< b << ", " << a << ")"<< endl; 
    if  (b < a)	      // Base case
        return  0;
    else			// General case
    {
      return (1 + Find (b - a, a));
    }
}
int main(int argc, char** argv) {
	cout << "Find(10, 4)=" << Find(10, 4) << endl; 
	return 0;
}



