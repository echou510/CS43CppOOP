#include <iostream>
using namespace std; 

// Recursive definition of power function 
// Pre:  n >= 0; x, n are not both zero
// Post: Return value == x raised to the 
//  power n.
int  Power ( int   x,   int   n){
    if  (n == 0)
        return  1; // Base case

    else           // General case
        return ( x * Power (x, n-1));         
} 

int main(int argc, char** argv) {
	cout << Power (2, 6) << endl; 
	return 0;
}



