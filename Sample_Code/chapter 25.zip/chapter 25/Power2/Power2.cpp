#include <iostream>
using namespace std; 
// Recursive definition of power function 
// Pre:  x  !=  0 && Assigned(n)
// Post: Return value == x raised to the power n
float Power(/*in*/ float x,  /*in*/ int n){
    if  (n == 0)      // Base case
        return  1;
    else  if  (n > 0) // First  general  case
        return ( x * Power (x, n - 1));
    else 	            // Second general case
        return ( 1.0 / Power (x, - n));
} 

int main(int argc, char** argv) {
    cout << Power(2, 3) << endl; 
    cout << Power(2, -3) << endl; 
	return 0;
}


