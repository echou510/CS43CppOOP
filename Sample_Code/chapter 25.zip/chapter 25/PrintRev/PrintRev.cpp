#include <iostream>
using namespace std; 
void PrintRev(const int data[], int first, int last ){
	if (first <= last)	// Recursive case
	{
		PrintRev(data, first+1, last);
		cout << data[first] << endl;
	}
	// Empty else-clause is the base-case
}

int main(int argc, char** argv) {
	int data[3] = {0, 1, 2};
	PrintRev(data, 0, 2);   
	return 0;
}



