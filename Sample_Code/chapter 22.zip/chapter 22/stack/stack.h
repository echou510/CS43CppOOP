#ifndef STACK_H
#define STACK_H
#include "list.h"  // List class definition

template< class STACKTYPE >
class Stack  {
    public:
	   // data
	   List<STACKTYPE> * list; 
	   Stack() {  list = new List<STACKTYPE>();  }
       // push calls List function insertAtFront
       void push( const STACKTYPE &data ) {  list->insertAtFront( data );  } // end function push
       // pop calls List function removeFromFront
       bool pop( STACKTYPE &data ) {  return list->removeFromFront( data ); } // end function pop

       // isStackEmpty calls List function isEmpty
       bool isStackEmpty() const {  return list->isEmpty(); } // end function isStackEmpty

       // printStack calls List function print
       void printStack() const  {  list->print();  } // end function print 
}; // end class Stack
#endif



