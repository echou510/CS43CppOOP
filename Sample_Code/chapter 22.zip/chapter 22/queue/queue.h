#ifndef QUEUE_H
#define QUEUE_H
#include "list.h"  // List class definition

template< class QUEUETYPE >
class Queue : private List< QUEUETYPE > {    
    public:
	   // data
	   List<QUEUETYPE> * list; 
	   Queue() {  list = new List<QUEUETYPE>();  }
       // enqueue calls List function insertAtBack
       void enqueue( const QUEUETYPE &data ) {  list->insertAtBack( data );  } // end function enqueue
       // dequeue calls List function removeFromFront
       bool dequeue( QUEUETYPE &data ) {  return list->removeFromFront( data );  } // end function dequeue
       // isQueueEmpty calls List function isEmpty
       bool isQueueEmpty() const { return list->isEmpty(); } // end function isQueueEmpty
       // printQueue calls List function print
       void printQueue() const { list->print(); } // end function printQueue
   }; // end class Queue
#endif


