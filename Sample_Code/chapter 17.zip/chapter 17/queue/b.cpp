#include <iostream>
#include <string>
#include "linkedlist.h"
#include "node.h"
using namespace std; 

int main(){
	linkedlist<int> *a = new linkedlist<int>(); 
	cout << a->length << a->head << a->linkedlist<int>::size()<< endl; 
	return 0; 
}