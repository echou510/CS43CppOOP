#ifndef LINKEDLIST_H
#define LINKEDLIST_H
#include <iostream> 
#include <string>
#include <exception>
#include "node.h"
#include "to_string.h"
using namespace std; 

template <typename T> 
class linkedlist{
  public: 
     // data 
	 int length; 
	 node<T> *head, *tail; 
	 
	 // constructor
	 linkedlist(){ head=NULL; tail=NULL; length=0; }
	 
	 // methods
	 int size(){  return length; }

	 bool isempty(){ return (length==0); }
	
	int indexOf(T obj){
		node<T> *p = head; 
		int i = 0; 
		int idx = -1; 
		bool found = false; 
	
		while (p != NULL && !found){
			if (p->get() == obj){
				idx = i; 
			}
			i++;
			p = p->next; 
		}
		return idx; 
	} 
	
	 T get(int idx){
		T rtn; 
		node<T>*p = head; 
		if (head == NULL){
			throw "empty list";
		}
		if (idx<0 || idx>=length){
			throw "index out of bound";
		}
		for (int i=0; i<=idx; i++){
			if (i==idx) rtn = p->get(); 
			p = p->next; 
		}
		return rtn; 
	}
	 
	 string to_string(){
		string str("");
		node<T> *p = head; 
		str += "[";
		int count = 0; 	
		while (p!= NULL){
			if (count ==0) str += st::to_string(head->get());
			else str += ", "+ st::to_string(p->get());
			count++;
			p=p->next; 
		}	  
		str += "]"; 	
		return str; 
	}
	 
	 void set(int idx, T v){
		node<T>*p = head; 
		if (head == NULL){
			throw "empty list";
		}
		if (idx<0 || idx>=length){
			throw "index out of bound";
		}
		for (int i=0; i<=idx; i++){
			if (i==idx) p->set(v); 
			p = p->next; 
		}
	}
	 void add(T v){
		length++; 
		node<T> *n = new node<T>(v); 
		if (head == NULL){
			head = n; 
			head->next = NULL;
			tail = n; 
			return; 
		}
	    node<T> *p = (node<T> *) head; 
		node<T> *q = NULL; 
		while (p!= NULL){
			q = p; 
			p=p->next; 
		}  
		tail = n; 
		q->next = n; 
		n->next = NULL; 
	}
	
	 void add_front(T v){
		length++; 
		node<T> *n = new node<T>(v); 
		if (head == NULL){
			head = n; 
			head->next = NULL;
			tail = n; 
			return; 
		}	
	
		node<T> *p = (node<T> *) head; 
		head = n; 
		n->next = p; 
	}
	 void insert(int idx, T v){
		//cout << idx << "-"<< v << endl; 
		if (head == NULL){
			//length++; 
			add(v); 
			return; 
		}
		if (idx<0 || idx>length){
			throw "index out of bound";
		}	
	
		if (idx==0)          { add_front(v); return; }
		if (idx==length) { add(v);             return; }
	
		length++; 
		node<T>*p = head;
		node<T>*q = NULL; 
		for (int i=0; i<=idx; i++){
		if (i==idx) {
			//cout << i << " " << q->get() << " " << p->get() << endl; 
			node<T> *n = new node<T>(v); 
			q->next =n; 		  
			n->next =p;
		} 
		q = p; 
		p = p->next; 
		}
	}
	 node<T> *remove(){
		if (head == NULL){ // zero element
			return NULL; 
		}	
	
		length--; 
		node<T> *p = (node<T> *) head; 
		node<T> *q = NULL; 
		node<T> *r = NULL;
	    while (p!= NULL){
			r = q; 
			q = p; 
			p=p->next; 
		}  
	
		if (r==NULL){ // only one element
			head = NULL; 
			tail = NULL; 
			return q; 
		}
	
		r->next = NULL; 
		tail = r; 
		return q; 
	}
	 node<T> *remove_front(){
		if (head == NULL){ // zero element
			return NULL; 
		}	
	
		length--; 
		if (head->next == NULL){
			node<T>* q = head; 
			head = NULL; 
			tail = NULL; 
			return q; 
		}
	
		node<T>* q = head; 
		head = head->next; 
		return q; 
	}
	 void append(linkedlist<T> *alist){
		if (head == NULL) {
			head = alist->head;
			tail    = alist->tail;
			return;  		 
		}
	 
		tail->next = alist->head; 
		tail = alist->tail; 
	}
}; 
#endif