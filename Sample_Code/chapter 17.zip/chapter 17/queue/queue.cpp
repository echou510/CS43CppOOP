#include <iostream>
#include "queue.h"
using namespace std; 

#ifdef MAIN
int main(){
	queue<int> *q1 = new queue<int>(); 
	q1->enqueue(3); 
	q1->enqueue(4); 
	q1->enqueue(5); 
    cout << q1->size() << endl; 
	cout << q1->to_string() << endl; 
	cout << q1->dequeue()->get() << endl; 
	cout << q1->dequeue()->get() << endl; 
	cout << q1->size() << endl; 
	cout << q1->to_string() << endl; 
	return 0; 
}
#endif
