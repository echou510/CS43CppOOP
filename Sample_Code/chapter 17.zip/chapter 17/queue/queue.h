#define MAIN
#ifndef QUEUE_H
#define QUEUE_H
#include <iostream> 
#include <string>
#include "node.h"
#include "to_string.h"
#include "linkedlist.h"
using namespace std;

template <typename T>
class queue{
       public: 
	       // data
		   linkedlist<T> * list; 
		   
		   //methods
	       queue(){ list= new linkedlist<T>(); }
		   int size(){ return list->size(); }
           void enqueue(T v) { list->add_front(v); }
           string to_string() { return list->to_string(); }		
           node<T> *dequeue() {return list->remove(); }		   
}; 
#endif