// This program demonstrates the order in which base and 
// derived class constructors and destructors are called. 
#include <iostream>
using namespace std; 

//**********************************
// BaseClass declaration           *
//**********************************
class BaseClass{
   public: 
      BaseClass() // Constructor 
        {  cout << "This is the BaseClass constructor. " << endl; 
		}
     ~BaseClass() // Destructor 
        {  cout << "This is the BaseClass destructor. " << endl;
		}
};

class DerivedClass: public BaseClass {
   public: 
      DerivedClass() // Constructor 
        {  cout << "This is the DerivedClass constructor. " << endl; 
		}
     ~DerivedClass() // Destructor 
        {  cout << "This is the DerivedClass destructor. " << endl;  
		}
};

int main(int argc, char** argv) {
	cout << "We will now define a DerivedClass objects. " << endl ; 
	DerivedClass object; 
	cout << "The program is now going to end. " << endl; 
	return 0;
}


